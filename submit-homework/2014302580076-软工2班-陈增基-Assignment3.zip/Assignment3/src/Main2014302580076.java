
public class Main2014302580076 {


	public static void main(String[] args) throws ClassNotFoundException {
		// TODO �Զ����ɵķ������
		SingleThread2014302580076 sgt = new SingleThread2014302580076();
		MultipleThread2014302580076 mtt=new MultipleThread2014302580076();
		long kaishi=System.currentTimeMillis();
		sgt.run();
		long jieshu=System.currentTimeMillis();
		System.out.println("���̺߳�ʱ : "+(jieshu-kaishi)+"ms");
		 kaishi=System.currentTimeMillis();
		   mtt.working();
		 jieshu=System.currentTimeMillis();
		System.out.println("���̺߳�ʱ : "+(jieshu-kaishi)+"ms");
	}

}
