import java.io.IOException;




import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class SingleThread2014302580076 implements Runnable {
private String[] names=new String[200];
private String[] fames=new String[200];
private String[] fields=new String[200];
private String[] phones=new String[200];
private String[] Emails=new String[200];
private String[] introds=new String[200];
private String[] urls=new String[200];
private PaChong2014302580076 pachonga;
private Storage2014302580076 storage;
private String tlist="http://staff.whu.edu.cn/?lang=cn";
private Document doc;
 public void run() /*throws ClassNotFoundException*/{
	 try {
			doc =Jsoup.connect(tlist).get(); 			
		} catch (IOException e) {
			e.printStackTrace();
		}
	 Element use=doc.select("div.page-content").first();
	 Elements links = use.select("a[href]"); 
		int t=0;
		for(Element link:links){
			//turls.add("http://staff.whu.edu.cn"+links.text())  ; 
			urls[t] ="http://staff.whu.edu.cn/"+link.attr("href");
		  t++;
		}
      // for(String tturl:turls)
    //	  pachonga.PaChong(urls[0], names[0], fames[0], fields[0], phones[0], Emails[0], introds[0]);
     //   storage.Store( names[0], fames[0], fields[0], phones[0], Emails[0], introds[0]);
			 for(int i=0;i<t;i++){
	
				pachonga=new PaChong2014302580076(urls[i]);
				pachonga.PaChong();
				names[i] =pachonga.getname();
				fames[i] =pachonga.getfame();
				fields[i] =pachonga.getfield();
				phones[i]=pachonga.getphone();
				Emails[i] =pachonga.getemail();
				introds[i] =pachonga.getintrod();
				storage=new Storage2014302580076(i,names[i], fames[i], fields[i], phones[i], Emails[i], introds[i]);
				 try {
						storage.Store();
					} catch (ClassNotFoundException e) {
						// TODO �Զ����ɵ� catch ��
						e.printStackTrace();
             }

				
				}
				 /*		  for(int i=0;i<t;i++){
		storage.Store(names[i], fames[i], fields[i], phones[i], Emails[i], introds[i]);
	              }
	*/ 

}
 
 
}
