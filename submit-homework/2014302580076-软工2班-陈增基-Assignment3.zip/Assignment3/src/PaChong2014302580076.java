import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;


public class PaChong2014302580076 {
//	private Document doc =new Document("");
	private String url =new String();
	private String name=new String();
	private String fame=new String();
	private String field=new String();
	private String phone=new String();
	private String email=new String();
	private String introd=new String();  
	PaChong2014302580076(String url) {	this.url=url;	}
public void  PaChong(/* String url,String name,String fame,String field,String phone,String email,String introd*/) {
	
		
			 Document doc = new Document("");
			try {
				doc = (Document) Jsoup.connect(url).get();
			} catch (IOException e1) {
	
				e1.printStackTrace();
			}
		
	  Element zhuaqu =doc.select("div.details").first();
  name = zhuaqu.select("h3").get(0).text();  
            	
   Element multitem=zhuaqu.select("p").first();
   fame=multitem.childNode(0).toString();
   field=multitem.childNode(2).toString();
    Pattern p=Pattern.compile("\\w+@\\w+\\.\\w+.\\w+");
	  String u=multitem.text();                                                                           
	 Matcher m=p.matcher(u);
	try{ m.find();
	email=m.group();}
	catch(IllegalStateException e){
		email="none";
	}
      p =Pattern.compile("(0\\d{2}-\\d{8})|([0-9]{11})");                                                
m=p.matcher(u);
	  try{  m.find();
	    phone=m.group();  }
	  catch(IllegalStateException e){
		  phone="none";//�ҵ��绰
	  }
	 zhuaqu =doc.select("div.details").last();
 introd = zhuaqu.text(); 
}

public String getname(){return name;}
public String getfame(){return fame;}
public String getfield(){return field;}
public String getphone(){return phone;}
public String getemail(){return email;}
public String getintrod(){return introd;}
  

}
