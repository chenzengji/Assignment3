import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class MultipleThread2014302580076 {
	private String[] names=new String[200];
	private String[] fames=new String[200];
	private String[] fields=new String[200];
	private String[] phones=new String[200];
	private String[] Emails=new String[200];
	private String[] introds=new String[200];
	private String[] urls=new String[200];
	private PaChong2014302580076 pachonga;
	private Storage2014302580076 storage;
	private long kaishi ;
	private long jieshu ;
	private String tlist="http://staff.whu.edu.cn/?lang=cn";
	private Document doc;
	private int t;
	private int pt;
	private int st;
	 public void working() throws ClassNotFoundException{
		 kaishi=System.currentTimeMillis();
		 try {
				doc =Jsoup.connect(tlist).get(); 			
			} catch (IOException e) {
				e.printStackTrace();
			}
		 Element use=doc.select("div.page-content").first();
		 Elements links = use.select("a[href]"); 
			 t=0;
			for(Element link:links){
				//turls.add("http://staff.whu.edu.cn"+links.text())  ; 
				urls[t] ="http://staff.whu.edu.cn/"+link.attr("href");
			  t++;
			}
			new Thread(new Thread1()).start();
			new Thread(new Thread2()).start();
		
  }
		class Thread1 implements Runnable{

			public void run() {
				pt=0;
           for(int i=0;i<t;i++){
        	   pachonga=new PaChong2014302580076(urls[i]);
				pachonga.PaChong();
				names[i] =pachonga.getname();
				fames[i] =pachonga.getfame();
				fields[i] =pachonga.getfield();
				phones[i]=pachonga.getphone();
				Emails[i] =pachonga.getemail();
				introds[i] =pachonga.getintrod();
                pt++;
            
           }
			}
		}
		class Thread2 implements Runnable{

			public void run() {
				st=0;
            for(int i=0;i<t;i++){
             while(st==pt){System.out.print("");}
            	storage=new Storage2014302580076(i,names[i], fames[i], fields[i], phones[i], Emails[i], introds[i]);
                try {
					storage.Store();
				} catch (ClassNotFoundException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
            	st++;  
            	
            	if(st==t){jieshu=System.currentTimeMillis();
    			System.out.println("true���̺߳�ʱ : "+(jieshu-kaishi)+"ms");}
            }
			}
		}
}
