import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Storage2014302580076 {
	private String name=new String();
	private String fame=new String();
	private String field=new String();
	private String phone=new String();
	private String email=new String();
	private String introd=new String();
	private  int id;
	Storage2014302580076(int id,String name,String fame,String field,String phone,String email,String introd){
		this.name=name;
		this.fame=fame;
		this.field=field;
		this.phone=phone;
		this.email=email;
		this.introd=introd;
		this.id=id+1;
	}
	public void Store()throws ClassNotFoundException{
		 Class.forName("com.mysql.jdbc.Driver");
			try {
				Connection conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/teacherlist","root","123456");
				Statement statement=conn.createStatement();
				if(id==1){statement.executeUpdate("delete from tlist");}
				String pid=String.format("%d", id);
				 statement.executeUpdate("Insert into tlist values('"+pid+"','"+name+"','"+fame+"','"+field+"','"+phone+"','"+email+"','"+introd+"');");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	

}
